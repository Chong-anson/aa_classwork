// myEach 
const array1 = [5, 2, 6];
let sum = 0; 

function block(element) {
  sum += element
};

// Another way to define block 
// const block = function(element) {
//   sum += element;
// }

Array.prototype.myEach = function(callback) {
  for (let i = 0; i < this.length; i++) {
    callback(this[i]);
  }
}

array1.myEach(block);

// Fat arrow
// array1.myEach(x => block(x));

// Pass in the whole function
// array1.myEach(function(x) { 
//   sum += x
// })

// console.log(sum);

// myMap 

Array.prototype.myMap = function(map) { 
  let result = [];
  // this.myEach(x => result.push(map(x)));
  this.myEach(function(x) {
    result.push(map(x))
  });
// this.myEach do |x| 
// result << callback(x) 
// end

  return result; 
}

function mulitplier(element) {
  element *= 2;
  return element
}

// console.log([2,3,4].myEach(mulitplier))
console.log([2,3,4].myMap(mulitplier));
