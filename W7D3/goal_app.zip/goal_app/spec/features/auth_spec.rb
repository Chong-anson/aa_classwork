require 'spec_helper'
require 'rails_helper'

feature 'the signup process' do
  background :each do 
    visit new_user_path
  end

  scenario 'has a new user page' do
    expect(page).to have_content("Sign Up")  
  end
  
  feature 'signing up a user' do
    
    scenario 'shows username and email on the homepage after signup' do 
      expect(page).to have_content("username:")  
      expect(page).to have_content("email:")  
    end 
  end
end

feature 'logging in' do
  background :each do 
    visit new_user_path
  end
  scenario 'shows username on the homepage after login' do 
    fill_in "username:", with: "Jon Snow"
    fill_in "email:", with: "jon@aa.io"
    fill_in "password:", with: "123456"
    click_button "Submit"

    expect(page).to have_content("Jon Snow")
    user = User.find_by(username: "Jon Snow")
    expect(current_path).to eq(user_path(user))
  end

end

feature 'logging out' do
  
  scenario 'begins with a logged out state'

  scenario 'doesn\'t show username on the homepage after logout'

end