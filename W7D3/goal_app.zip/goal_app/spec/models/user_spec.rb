require 'rails_helper'

RSpec.describe User, type: :model do
  # pending "add some examples to (or delete) #{__FILE__}"
  #username, email, password, 
  subject(:kevin) { User.new(username: "kevbot", email:"kevbot@@aa.io", password: "hunter12")}
  it { should validate_presence_of(:username) }
  it { should validate_presence_of(:email) }
  it { should validate_presence_of(:password) }
  it { should validate_length_of(:password).is_at_least(6) }
  it { should validate_uniqueness_of(:username) }

  describe 'ensure_session_token' do
    it 'assigns a session_token if none is given' do
      expect(FactoryBot.build(:user).session_token).not_to be_nil
    end
  end

  describe 'reset_session_token!' do
    it 'should return a new session token' do 
      user = FactoryBot.build(:user)
      old_session_token = user.session_token
      user.reset_session_token!
      expect(user.session_token).to_not eq(old_session_token)
    end
  end

  describe 'password=' do
    it 'should not save password to the database' do
      user = FactoryBot.create(:user)
      expect(User.find(user.id).password).to be_nil
      #find_by(username: user.username)
    end
  end

  describe 'is_password?' do
    it 'should return true if the password is valid' do
      user = FactoryBot.build(:user)
      password = user.password
      expect(user.is_password?(password)).to be true
    end

    it 'should return false if the password is invalid' do
      user = FactoryBot.build(:user)
      password = user.password+"abc"
      expect(user.is_password?(password)).to be false
    end

  end

  describe 'find_by_credentials' do 
    it 'should return nil if no user is found' do
      user = FactoryBot.build(:user)
      expect(User.find_by_credentials(user.username ,user.password )).to be_nil
    end

    it 'should return the user if credentials are valid' do 
      user = FactoryBot.create(:user)
      expect(User.find_by_credentials(user.username ,user.password )).to eq(user)
    end
  end


end
