FactoryBot.define do
  factory :user do
    username { Faker::TvShows::GameOfThrones.character }
    email { 'email@aa.io'}
    password { 'password' }
    
  end
end
