require 'rails_helper'

RSpec.describe UsersController, type: :controller do
  describe 'GET #new' do
    it 'renders a form to create a user' do
      get :new
      expect(response).to render_template(:new)
    end
  end

  describe 'POST #create' do
    let (:user_params) do 
      {user: {username: "Kevin", email: "kevbot@aa.io", password: "hunter12"}}
    end

    context 'with valid params' do
      it 'logs the user in and redirect the user' do
        post :create, params: user_params
        user = User.find_by(username: "Kevin")
        expect(session[:session_token]).to eq(user.session_token)
        expect(response).to redirect_to(user_url(user))
      end
    end

    context 'with invalid params' do
      let (:user_params) do 
        {user: {username: "Kevin", email: "", password: "hunter12"}}
      end
      it 'denies the creation and renders :new template' do
        post :create, params: user_params
        expect(response).to render_template(:new) 
        expect(flash[:errors]).to be_present 
      end
    end
  end

  describe "DELETE #destroy" do 
    it "should delete a user and redirect to users_url" do
      user = FactoryBot.create(:user)
      # debugger
      delete :destroy, params: {id: user.id}
      expect(User.find_by(id: user.id)).to be_nil 
      expect(response).to redirect_to(users_url) 
    end 
  end
end
